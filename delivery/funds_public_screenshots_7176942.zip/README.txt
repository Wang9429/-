资金页公网截图（GitHub Pages）
站点: https://wang9429.github.io/-/funds/
提交: 71769426983d998680c9f6331688ead9ff93a996
工作流: https://github.com/Wang9429/-/actions/runs/35103732385
截取时间: 2026-09-16，无痕浏览器，未登录 GitHub
