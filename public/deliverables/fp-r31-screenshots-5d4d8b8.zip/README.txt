提交 5d4d8b8
来源 http://127.0.0.1:43917
R3.1 截图：
- r31-funds-full-catalog.png 资金全部专题 11 项一级目录
- r31-rights-full-catalog.png 产权全部专题 10 项一级目录
- r31-rights-trade.png 产权交易（选定经济行为后的下拉+肩形流程）
- r31-rights-nontrade.png 非交易专题（无经济行为、无流程）
- r31-rights-kpi-no-formula-trend.png 产权四卡：无公式、无趋势
- r31-rights-indicator-detail-no-trend.png 产权指标详情：无趋势图，公式仅在计算依据
资金趋势仍有效：
- funds-upper-kpis.png 资金盈利能力主卡与小趋势
- r3-funds-revenue-detail-trend.png 营业收入详情趋势与同分类切换
